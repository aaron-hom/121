package com.example.dustinadams.listwithjson;

public class ListData {
    public String firstText;
    public String secondText;
    public String thirdText;
    public String fourthText;
    public String fifthText;
}
